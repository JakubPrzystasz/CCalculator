#include <stdbool.h>
#include <stdlib.h>

#ifndef CALCULATOR_H
#define CALCULATOR_H

	int freeArray(char** array, size_t size);
    int appendToString(char* string, char* value);
    int popArray(char** array, int* count);
	int appendToArray(char** array, char* string, int* count);
	int insertToArray(char** array, char* string, int* count, int index);
	int editInArray(char** array, char* string, int* count, int index);
	int removeInArray(char** array, int* count, int index);
	int editInArray(char** array,char* string,int* count, int index);
	int parseExpression(char* expression, int* length);
	int toRPN(char** expressionArray, int* length);
	int doMath(int operator,char* arg1, char* arg2);
	int getOperator(char* expression);
	int getOperatorPriority(int* operator);
	bool isFunction(char* expression);
	bool isNumber(char* expression);
	bool isDigit(char* expression);
	double compute(char** expressionArray, int* length);
#endif
