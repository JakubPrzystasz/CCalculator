#define _CRT_SECURE_NO_WARNINGS
#include "calculator.h"
#include <stdlib.h>
#include <string.h>

/* DOPISZ WARTOSC NA KONIEC STRINGA */

int appendToString(char* string, char* value) {
	//INITIALIZE NEW STRING
	if (string == NULL) {
        string = (char*)malloc(strlen(value) * sizeof(char));
		if (string == NULL) {
			return 1;
		}
		string = strcpy(string, value);
	} else {
    //APPEND VALUE TO EXISITING STRING
        string = (char*)realloc(string, (strlen((char*)string) + 2) * sizeof(char));
		if (string == NULL) {
			return 1;
		}
        char* tmpString = string;
		string = strcat(string, value);
		if(string == NULL){
            string = tmpString;
            return 1;
		}
	}
	return 0;
}
